package com.nxtbus.owner;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}