package com.nxtbus.driver;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}